/* DataQuest – Explore Beyond Data | Exploratory Data Analysis platform (vanilla JS) */
(()=>{
'use strict';
const $=(s,e=document)=>e.querySelector(s),$$=(s,e=document)=>[...e.querySelectorAll(s)];
const PG=[['index','Home','🏠'],['questions','Ask Questions','❓'],['structure','Data Structure','🗂️'],['patterns','Discover Patterns','📊'],['hypothesis','Hypothesis Lab','🧪'],['quality','Data Quality','🛡️'],['insights','Final Insights','💡']];
const cur=document.body.dataset.page,XCDN='https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
const LS={get(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const f=v=>!isFinite(v)?'–':Math.abs(v)>=1e4?(v/1e3).toFixed(1)+'k':+(+v).toFixed(2);
const sum=a=>a.reduce((p,c)=>p+c,0),mn=a=>a.reduce((p,c)=>c<p?c:p,Infinity),mx=a=>a.reduce((p,c)=>c>p?c:p,-Infinity);
const pf=p=>isNaN(p)?'–':p<1e-4?'< 0.0001':p.toFixed(4);
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),3400)}
function save(name,txt,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([txt],{type}));a.download=name;document.body.appendChild(a);a.click();a.remove();toast('Downloaded '+name)}

/* ---------- sample data ---------- */
function sample(){let s=42;const r=()=>(s=(s*16807)%2147483647)/2147483647,g=()=>Math.sqrt(-2*Math.log(r()+1e-9))*Math.cos(6.2832*r()),dep=['Computer Science','Engineering','Business','Arts'],rows=[];
for(let i=1;i<=200;i++){const age=Math.round(18+r()*8),h=Math.max(0,+(4+g()*1.8).toFixed(1)),att=Math.min(100,Math.max(40,Math.round(75+g()*12))),sc=Math.min(100,Math.max(0,Math.round(28+h*7+att*.22+g()*6)));
rows.push([1000+i,age,h,att,sc,r()<.5?'Male':'Female',dep[Math.floor(r()*4)],r()<.8?'Yes':'No'])}
rows[5][4]='';rows[17][3]='';rows[40][2]='';rows[60][4]='';rows[90][3]='';rows[10][2]=19.5;rows[25][4]=3;rows[120][2]=17;rows[30][1]='twenty';rows[70][6]='engineering ';rows[80][5]='male';
rows.push([...rows[0]],[...rows[1]],[...rows[2]]);
return{name:'Student Performance (sample)',cols:['StudentID','Age','StudyHours','Attendance','FinalScore','Gender','Department','HasInternet'],rows}}
const SAMPLE_INFO='A synthetic dataset of 203 students used for demonstration. Study hours and attendance drive the final score, and it deliberately contains missing values, duplicates, outliers, a mixed-type entry and inconsistent labels so every EDA stage has something to find.';

/* ---------- parsing ---------- */
function csv(t){t=t.replace(/^\uFEFF/,'');const fl=t.split('\n')[0],dl=[',',';','\t'].map(d=>[d,fl.split(d).length]).sort((a,b)=>b[1]-a[1])[0][0],R=[];let r=[],x='',q=false;
for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c=='"'){if(t[i+1]=='"'){x+='"';i++}else q=false}else x+=c}else if(c=='"')q=true;else if(c==dl){r.push(x);x=''}else if(c=='\n'||c=='\r'){if(c=='\r'&&t[i+1]=='\n')i++;r.push(x);R.push(r);r=[];x=''}else x+=c}
if(x!==''||r.length){r.push(x);R.push(r)}return R}
const loadX=()=>new Promise((ok,no)=>{if(window.XLSX)return ok();const s=document.createElement('script');s.src=XCDN;s.onload=ok;s.onerror=()=>no(new Error('Excel reader needs an internet connection – please upload a CSV instead'));document.head.appendChild(s)});
const toCSV=(h,rows)=>[h,...rows].map(r=>r.map(v=>{v=String(v??'');return /[",\n;]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v}).join(',')).join('\n');

/* ---------- dataset state ---------- */
let DS=LS.get('dq_ds',null)||sample(),PC=null,QC=null;
function setDS(d){DS=d;PC=QC=null;if(!LS.set('dq_ds',d)){d.rows=d.rows.slice(0,4000);if(LS.set('dq_ds',d))toast('Large file: first 4,000 rows kept so it works across pages');else toast('File too large to keep between pages – analysis works on this page only')}}
const isMiss=v=>v===''||v==null||/^(na|n\/a|nan|null|none|-)$/i.test(String(v).trim());
const num=v=>{if(typeof v==='number')return v;const s=String(v).replace(/,/g,'').trim();return s===''?NaN:+s};
const isId=n=>/^(id|index|#)$/i.test(n)||/[_\s-]id$/i.test(n)||/^id[_\s-]/i.test(n)||/[a-z]ID$/.test(n);

function prof(){if(PC)return PC;const n=DS.rows.length;
return PC=DS.cols.map((name,j)=>{const raw=DS.rows.map(r=>r[j]),pres=raw.filter(v=>!isMiss(v)),nums=[];
pres.forEach(v=>{const x=num(v);if(!isNaN(x))nums.push(x)});
const share=pres.length?nums.length/pres.length:0,isNum=share>=.9&&nums.length>0,tr=pres.map(v=>String(v).trim()),uniq=new Set(tr).size;
const c={name,j,n:pres.length,miss:n-pres.length,uniq,share,isNum,id:isNum&&isId(name),mixed:share>.5&&share<1,ws:pres.filter(v=>typeof v==='string'&&v!==v.trim()).length,
type:isNum?(nums.every(Number.isInteger)?'Integer':'Float'):(uniq<=Math.max(20,n*.05)?'Categorical':'Text'),sample:[...new Set(tr)].slice(0,3).join(', ')};
c.case=isNum?0:uniq-new Set(tr.map(v=>v.toLowerCase())).size;
if(isNum){const s=[...nums].sort((a,b)=>a-b),q=p=>{const i=(s.length-1)*p,lo=Math.floor(i);return s[lo]+(s[Math.min(lo+1,s.length-1)]-s[lo])*(i-lo)};
const mean=sum(s)/s.length,sd=Math.sqrt(sum(s.map(a=>(a-mean)**2))/Math.max(1,s.length-1)),q1=q(.25),q3=q(.75),lo=q1-1.5*(q3-q1),hi=q3+1.5*(q3-q1);
Object.assign(c,{nums,s,mean,sd,min:s[0],max:s[s.length-1],med:q(.5),q1,q3,lo,hi,out:s.filter(v=>v<lo||v>hi).length,sk:sd?sum(s.map(a=>((a-mean)/sd)**3))/s.length:0})}
else{const m={};tr.forEach(v=>m[v]=(m[v]||0)+1);c.freq=Object.entries(m).sort((a,b)=>b[1]-a[1])}
return c})}
const numCols=()=>prof().filter(c=>c.isNum&&!c.id),catCols=()=>prof().filter(c=>!c.isNum);
function pairs(a,b){const X=[],Y=[];DS.rows.forEach(r=>{const x=num(r[a.j]),y=num(r[b.j]);if(!isMiss(r[a.j])&&!isMiss(r[b.j])&&!isNaN(x)&&!isNaN(y)){X.push(x);Y.push(y)}});return[X,Y]}

/* ---------- statistics ---------- */
function lg(x){const c=[76.18009172947146,-86.50532032941677,24.01409824083091,-1.231739572450155,.1208650973866179e-2,-.5395239384953e-5];let y=x,t=x+5.5,s=1.000000000190015;t-=(x+.5)*Math.log(t);for(const k of c)s+=k/++y;return -t+Math.log(2.5066282746310005*s/x)}
function bc(a,b,x){const qab=a+b,qap=a+1,qam=a-1,T=1e-30;let c=1,d=1-qab*x/qap;if(Math.abs(d)<T)d=T;d=1/d;let h=d;for(let m=1;m<200;m++){const m2=2*m;let aa=m*(b-m)*x/((qam+m2)*(a+m2));d=1+aa*d;if(Math.abs(d)<T)d=T;c=1+aa/c;if(Math.abs(c)<T)c=T;d=1/d;h*=d*c;aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2));d=1+aa*d;if(Math.abs(d)<T)d=T;c=1+aa/c;if(Math.abs(c)<T)c=T;d=1/d;const l=d*c;h*=l;if(Math.abs(l-1)<3e-7)break}return h}
function betai(a,b,x){if(x<=0)return 0;if(x>=1)return 1;const bt=Math.exp(lg(a+b)-lg(a)-lg(b)+a*Math.log(x)+b*Math.log(1-x));return x<(a+1)/(a+b+2)?bt*bc(a,b,x)/a:1-bt*bc(b,a,1-x)/b}
const pT=(t,df)=>betai(df/2,.5,df/(df+t*t)),tcrit=df=>{let lo=0,hi=100;for(let i=0;i<50;i++){const m=(lo+hi)/2;pT(m,df)>.05?lo=m:hi=m}return hi};
function pear(X,Y){const n=X.length;if(n<3)return{r:NaN,n};const mx_=sum(X)/n,my=sum(Y)/n;let sxy=0,sxx=0,syy=0;for(let i=0;i<n;i++){sxy+=(X[i]-mx_)*(Y[i]-my);sxx+=(X[i]-mx_)**2;syy+=(Y[i]-my)**2}
const r=sxy/Math.sqrt(sxx*syy),t=r*Math.sqrt((n-2)/(1-r*r));return{r,n,t,p:pT(t,n-2),a:sxy/sxx,b:my-sxy/sxx*mx_}}
const strength=r=>{r=Math.abs(r);return r<.1?'negligible':r<.3?'weak':r<.5?'moderate':r<.7?'strong':'very strong'};
function corrs(){const nu=numCols().slice(0,12),o=[];for(let i=0;i<nu.length;i++)for(let j=i+1;j<nu.length;j++){const[X,Y]=pairs(nu[i],nu[j]),p=pear(X,Y);if(isFinite(p.r))o.push({a:nu[i],b:nu[j],...p})}return o.sort((x,y)=>Math.abs(y.r)-Math.abs(x.r))}
const skewTxt=s=>Math.abs(s)<.5?'fairly symmetric':Math.abs(s)<1?(s>0?'moderately right-skewed':'moderately left-skewed'):(s>0?'strongly right-skewed':'strongly left-skewed');

function qual(){if(QC)return QC;const cs=prof(),n=DS.rows.length,miss=sum(cs.map(c=>c.miss)),seen=new Set();let dup=0;
DS.rows.forEach(r=>{const k=r.join('\u0001');seen.has(k)?dup++:seen.add(k)});
const nu=cs.filter(c=>c.isNum&&!c.id),outs=sum(nu.map(c=>c.out)),mixed=cs.filter(c=>c.mixed),cons=cs.filter(c=>c.uniq<=1&&n>1),ws=cs.filter(c=>c.ws),cse=cs.filter(c=>c.case>0),I=[];
const sev=p=>p>20?'High':p>5?'Medium':'Low';
cs.forEach(c=>{if(c.miss)I.push([sev(c.miss/n*100),c.name,`${c.miss} missing values (${(c.miss/n*100).toFixed(1)}%)`,c.isNum?'Impute with median or drop rows':'Impute with mode or label "Unknown"']);
if(c.mixed)I.push(['High',c.name,`Inconsistent types: ${((1-c.share)*100).toFixed(1)}% of entries are not numeric`,'Find and correct non-numeric entries']);
if(c.ws)I.push(['Low',c.name,`${c.ws} values with leading/trailing spaces`,'Trim whitespace']);
if(c.case>0)I.push(['Medium',c.name,`Inconsistent labels (${c.case} case variants of the same category)`,'Standardise capitalisation']);
if(c.uniq<=1&&n>1)I.push(['Low',c.name,'Constant column – only one distinct value','Drop – it carries no information']);
if(c.isNum&&!c.id&&c.out)I.push([sev(c.out/c.n*100*2),c.name,`${c.out} outliers outside [${f(c.lo)}, ${f(c.hi)}] (IQR rule)`,'Verify; cap, transform or remove if errors'])});
if(dup)I.unshift([sev(dup/n*100*2),'(all columns)',`${dup} exact duplicate rows`,'Remove duplicates']);
const score=Math.round(Math.max(0,100-Math.min(35,miss/(n*cs.length||1)*250)-Math.min(20,dup/n*400)-mixed.length*5-Math.min(15,outs/(n*(nu.length||1))*300)-cons.length*3-(ws.length+cse.length)*2));
return QC={n,miss,dup,mixed,outs,cons,ws,cse,issues:I,score,cells:n*cs.length}}

/* ---------- charts (canvas) ---------- */
const R=[];
function chart(c,type,o){cancelAnimationFrame(c._r);const d=devicePixelRatio||1,W=c.clientWidth,H=c.clientHeight;c.width=W*d;c.height=H*d;
const x=c.getContext('2d'),m={l:48,r:14,t:14,b:40},pw=W-m.l-m.r,ph=H-m.t-m.b;c._h=[];let x0=0,x1=1,y0=0,y1=1;
if(type==='bars')y1=Math.max(mx(o.v),1e-9)*1.12;
if(type==='scatter'){x0=mn(o.x);x1=mx(o.x);y0=mn(o.y);y1=mx(o.y);const a=(x1-x0||1)*.05,b=(y1-y0||1)*.05;x0-=a;x1+=a;y0-=b;y1+=b}
if(type==='line'){x0=0;x1=o.v.length-1||1;y0=mn(o.v);y1=mx(o.v);const b=(y1-y0||1)*.08;y0-=b;y1+=b}
const X=v=>m.l+(v-x0)/(x1-x0||1)*pw,Y=v=>m.t+ph-(v-y0)/(y1-y0||1)*ph,G=()=>{const g=x.createLinearGradient(0,m.t,0,m.t+ph);g.addColorStop(0,'#22d3ee');g.addColorStop(.55,'#6366f1');g.addColorStop(1,'#a855f7');return g};
const frame=t=>{x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,W,H);x.font='11px system-ui';x.strokeStyle='rgba(255,255,255,.07)';x.fillStyle='#9a9cc4';x.textAlign='right';
for(let i=0;i<=4;i++){const v=y0+(y1-y0)*i/4,y=Y(v);x.beginPath();x.moveTo(m.l,y);x.lineTo(W-m.r,y);x.stroke();x.fillText(f(v),m.l-6,y+4)}
x.textAlign='center';
if(type==='bars'){const n=o.v.length,bw=pw/n,st=Math.ceil(n/Math.max(1,Math.floor(pw/62)));o.v.forEach((v,i)=>{const h=v/y1*ph*t,bx=m.l+i*bw+bw*.1;x.save();x.shadowColor='rgba(99,102,241,.7)';x.shadowBlur=10;x.fillStyle=G();x.fillRect(bx,m.t+ph-h,bw*.8,h);x.restore();
if(i%st===0){x.fillStyle='#9a9cc4';x.fillText(String(o.l[i]).slice(0,12),bx+bw*.4,H-m.b+16)}
if(t===1)c._h.push({x:bx,y:m.t,w:bw*.8,h:ph,t:`${o.l[i]}: ${f(v)}`})})}
else{for(let i=0;i<=4;i++){x.fillStyle='#9a9cc4';x.fillText(f(x0+(x1-x0)*i/4),X(x0+(x1-x0)*i/4),H-m.b+16)}
if(type==='scatter'){x.globalAlpha=t;o.x.forEach((a,i)=>{x.beginPath();x.arc(X(a),Y(o.y[i]),3.6,0,6.3);x.fillStyle='rgba(99,102,241,.65)';x.fill();x.strokeStyle='#22d3ee';x.lineWidth=.8;x.stroke();if(t===1)c._h.push({x:X(a)-4,y:Y(o.y[i])-4,w:8,h:8,t:`(${f(a)}, ${f(o.y[i])})`})});
if(o.line){x.beginPath();x.moveTo(X(x0),Y(o.line.a*x0+o.line.b));x.lineTo(X(x1),Y(o.line.a*x1+o.line.b));x.strokeStyle='#a855f7';x.lineWidth=2.5;x.setLineDash([7,5]);x.stroke();x.setLineDash([])}x.globalAlpha=1}
else{x.save();x.beginPath();x.rect(0,0,m.l+pw*t,H);x.clip();x.beginPath();o.v.forEach((v,i)=>i?x.lineTo(X(i),Y(v)):x.moveTo(X(i),Y(v)));x.lineWidth=2.4;x.strokeStyle=G();x.shadowColor='#6366f1';x.shadowBlur=12;x.stroke();x.shadowBlur=0;x.lineTo(X(o.v.length-1),m.t+ph);x.lineTo(X(0),m.t+ph);x.fillStyle='rgba(99,102,241,.14)';x.fill();x.restore();
if(t===1)o.v.forEach((v,i)=>c._h.push({x:X(i)-4,y:Y(v)-6,w:8,h:12,t:`#${o.i?o.i[i]:i+1}: ${f(v)}`}))}}
if(o.xl){x.fillStyle='#c4c6ff';x.fillText(o.xl,m.l+pw/2,H-4)}};
const t0=performance.now();(function step(ts){const t=Math.min(1,(ts-t0)/650);frame(1-(1-t)**3);if(t<1)c._r=requestAnimationFrame(step)})(t0);
c.onmousemove=e=>{const b=c.getBoundingClientRect(),mx_=e.clientX-b.left,my=e.clientY-b.top,h=c._h.find(q=>mx_>=q.x&&mx_<=q.x+q.w&&my>=q.y&&my<=q.y+q.h),t=$('#tip');if(h){t.textContent=h.t;t.style.cssText=`display:block;left:${e.clientX+12}px;top:${e.clientY+12}px`}else t.style.display='none'};
c.onmouseleave=()=>$('#tip').style.display='none'}
function plot(id,type,o){const c=typeof id==='string'?$(id):id;if(!c)return;R.push(()=>chart(c,type,o));chart(c,type,o)}
let rt;window.addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(()=>R.forEach(g=>g()),200)});
function hist(c,k){k=k||Math.min(20,Math.max(6,Math.ceil(Math.sqrt(c.nums.length))));const w=(c.max-c.min)/k||1;const v=Array(k).fill(0);c.s.forEach(a=>v[Math.min(k-1,Math.floor((a-c.min)/w))]++);return{l:v.map((_,i)=>f(c.min+i*w)),v}}
function sampleXY(X,Y,k=1500){if(X.length<=k)return[X,Y];const s=Math.ceil(X.length/k);return[X.filter((_,i)=>i%s==0),Y.filter((_,i)=>i%s==0)]}
const opts=(cs,sel)=>cs.map((c,i)=>`<option value="${i}" ${i===sel?'selected':''}>${esc(c.name)}</option>`).join('');
const warn=m=>`<div class="warn">⚠️ ${m}</div>`,need=m=>warn(`This tool needs ${m}. Upload a suitable dataset on the <a href="structure.html" style="text-decoration:underline">Data Structure</a> page.`);
const head=(ic,t,s)=>`<h1 class="pt">${ic} <span class="gt">${t}</span></h1><p class="sub">${s}</p>`;

/* ---------- shell ---------- */
let M;
function shell(){const i=PG.findIndex(p=>p[0]===cur),vis=LS.get('dq_vis',[]);if(!vis.includes(cur)){vis.push(cur);LS.set('dq_vis',vis)}
const pv=PG[(i+PG.length-1)%PG.length],nx=PG[(i+1)%PG.length],pc=Math.round(vis.length/PG.length*100);
$('#root').innerHTML=`<div class="bg"></div><aside class="side" id="side"><a class="logo" href="index.html"><span>◈ DataQuest</span><small>Explore Beyond Data</small></a><nav>${PG.map(p=>`<a href="${p[0]}.html" class="${p[0]===cur?'on':''}">${p[2]} ${p[1]}${vis.includes(p[0])?'<em>✓</em>':''}</a>`).join('')}</nav>
<div class="dsbox">Active dataset<b>${esc(DS.name)}</b>${DS.rows.length.toLocaleString()} rows × ${DS.cols.length} columns<br><button class="btn sm" id="rp" style="margin-top:8px">↺ Reset progress</button></div></aside>
<div class="wrap"><header class="top"><button id="menu" aria-label="Menu">☰</button><div class="trk"><div class="steps">${PG.map((p,k)=>`<a class="st ${vis.includes(p[0])?'done':''} ${p[0]===cur?'now':''}" href="${p[0]}.html" title="${p[1]}"><i>${vis.includes(p[0])?'✓':k+1}</i><em>${p[1]}</em></a>`).join('')}</div><div class="pbar"><i style="width:${pc}%"></i></div></div><span class="pct">${vis.length}/7 stages · ${pc}%</span></header>
<main id="main"></main><footer class="pn"><a class="btn" href="${pv[0]}.html">← ${pv[1]}</a><a class="btn glow" href="${nx[0]}.html">${nx[1]} →</a></footer></div>`;
M=$('#main');$('#menu').onclick=()=>$('#side').classList.toggle('open');$('#rp').onclick=()=>{LS.set('dq_vis',[cur]);location.reload()};
$$('.side nav a').forEach(a=>a.onclick=()=>$('#side').classList.remove('open'))}

/* ---------- pages ---------- */
const DESC={questions:'Frame the problem first – review guiding questions and save your own.',structure:'Upload CSV/Excel and inspect rows, columns and data types.',patterns:'Interactive charts for trends, distributions, relationships and anomalies.',hypothesis:'Test assumptions with correlation and t-tests, with visual evidence.',quality:'Detect missing values, duplicates, outliers and type problems.',insights:'Key findings, recommendations and a downloadable EDA report.'};
const stat=(ic,n,l,suf='')=>`<div class="card stat hov"><div class="ic">${ic}</div><b data-n="${n}">0</b><i>${suf}</i><span>${l}</span></div>`;
function counters(){$$('[data-n]').forEach(e=>{const t=+e.dataset.n;let s;const st=ts=>{s=s||ts;const p=Math.min(1,(ts-s)/1300);e.textContent=Math.round(t*(1-(1-p)**3)).toLocaleString();if(p<1)requestAnimationFrame(st)};requestAnimationFrame(st)})}

function home(){const q=qual();
M.innerHTML=`<section class="hero"><div class="badge">🚀 Task 2 · Exploratory Data Analysis</div><h1>Data<span class="gt">Quest</span></h1><h2>Explore Beyond Data</h2>
<p>An interactive analytics workspace that walks you through the full EDA workflow – from asking the right questions to uncovering patterns, testing hypotheses, cleaning data and reporting insights. Upload your own dataset and every chart and statistic updates instantly.</p>
<div class="row"><a class="btn glow big" href="questions.html">Start Exploring →</a><a class="btn big" href="structure.html">⬆ Upload Dataset</a></div></section>
<div class="grid4">${stat('📄',DS.rows.length,'Rows analysed')}${stat('🧬',DS.cols.length,'Variables')}${stat('✅',q.score,'Data quality score','/100')}${stat('🧭',7,'EDA stages')}</div>
<h3 class="sec">The 7-stage EDA journey</h3><div class="grid3">${PG.slice(1).map((p,i)=>`<a class="card hov" href="${p[0]}.html"><div class="ic">${p[2]}</div><h4>${i+1}. ${p[1]}</h4><p>${DESC[p[0]]}</p></a>`).join('')}</div>
<h3 class="sec">📚 Sample dataset information</h3><div class="card"><h4>Student Performance (built-in demo)</h4><p>${SAMPLE_INFO}</p>
<div class="tw" style="margin:14px 0"><table><tr><th>Variable</th><th>Type</th><th>Meaning</th></tr>${[['StudentID','Integer','Unique identifier'],['Age','Integer','Age in years (1 text entry planted)'],['StudyHours','Float','Daily study hours'],['Attendance','Integer','Class attendance %'],['FinalScore','Integer','Exam score out of 100 (target)'],['Gender','Categorical','Male / Female'],['Department','Categorical','Field of study'],['HasInternet','Categorical','Home internet access']].map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('')}</table></div>
<div class="row" style="justify-content:flex-start"><button class="btn glow" id="ls">Load sample dataset</button><button class="btn" id="ds">⬇ Download sample CSV</button></div></div>`;
$('#ls').onclick=()=>{setDS(sample());toast('Sample dataset loaded');setTimeout(()=>location.reload(),500)};$('#ds').onclick=()=>{const s=sample();save('student_performance_sample.csv',toCSV(s.cols,s.rows),'text/csv')};counters()}

const DEFQ=[['Objective','What business or research question should this analysis answer?'],['Objective','Who will use the results, and what decision will they support?'],['Context','What does each row represent (a person, transaction, event)?'],['Context','What does every variable mean, and in which unit is it measured?'],['Context','How, when and by whom was the data collected?'],['Sampling','Is this a sample or the full population – could it be biased?'],['Quality','Which values are missing, and why might they be missing?'],['Quality','Are there duplicates or impossible values (e.g. negative age)?'],['Distribution','What do the key variables look like – skewed, symmetric, multi-modal?'],['Relationships','Which variables move together, and could a third factor explain it?'],['Anomalies','Are outliers data errors or genuine extreme cases?'],['Action','What further data or tests are needed before drawing conclusions?']];
function questions(){const cs=numCols(),ct=catCols().filter(c=>c.uniq>=2&&c.uniq<=15),sug=[];
if(cs.length>1)sug.push(`Does ${cs[0].name} influence ${cs[cs.length>3?3:1].name}?`);cs.slice(0,2).forEach(c=>sug.push(`What is the distribution of ${c.name}, and are there outliers?`));if(ct[0]&&cs[0])sug.push(`Does ${cs[cs.length-1].name} differ across ${ct[0].name} groups?`);
DS.cols.length&&sug.push(`Which columns of "${DS.name}" have the most missing data?`);
const draw=()=>{const done=LS.get('dq_qa',[]),mine=LS.get('dq_q',[]);
$('#dq').innerHTML=DEFQ.map((q,i)=>`<div class="q ${done.includes(i)?'dn':''}"><div class="qt"><small>${q[0]}</small>${q[1]}</div><button class="btn sm" data-d="${i}">${done.includes(i)?'↩ Undo':'✔ Answered'}</button></div>`).join('');
$('#mq').innerHTML=mine.length?mine.map((q,i)=>`<div class="q"><div class="qt"><small>Your question</small>${esc(q)}</div><button class="btn sm" data-x="${i}">🗑 Delete</button></div>`).join(''):'<p class="note">No saved questions yet – add one above.</p>';
$('#sg').innerHTML=sug.map((q,i)=>`<div class="q"><div class="qt"><small>Suggested from your data</small>${esc(q)}</div><button class="btn sm" data-s="${i}">＋ Save</button></div>`).join('');
$('#cnt').textContent=`${done.length}/${DEFQ.length} answered · ${mine.length} custom`;
$$('[data-d]').forEach(b=>b.onclick=()=>{const k=+b.dataset.d;LS.set('dq_qa',done.includes(k)?done.filter(x=>x!==k):[...done,k]);draw()});
$$('[data-x]').forEach(b=>b.onclick=()=>{mine.splice(+b.dataset.x,1);LS.set('dq_q',mine);draw()});
$$('[data-s]').forEach(b=>b.onclick=()=>{mine.push(sug[+b.dataset.s]);LS.set('dq_q',mine);toast('Question saved');draw()})};
M.innerHTML=head('❓','Ask Questions','Great analysis starts before the first chart. Work through these guiding questions, then add your own – they are saved in your browser and included in the final report.')+
`<div class="card"><h3>✍️ Add your own question</h3><div class="add"><input type="text" id="nq" placeholder="e.g. Does attendance affect the final score?" maxlength="200"><button class="btn glow" id="aq">Save question</button></div><div id="mq"></div></div>
<h3 class="sec">Questions to ask before analysing <small class="note" id="cnt"></small></h3><div id="dq"></div><h3 class="sec">💡 Suggestions generated from the active dataset</h3><div id="sg"></div>`;
const add=()=>{const v=$('#nq').value.trim();if(!v)return toast('Type a question first');const m=LS.get('dq_q',[]);m.push(v);LS.set('dq_q',m);$('#nq').value='';toast('Question saved ✔');draw()};
$('#aq').onclick=add;$('#nq').onkeydown=e=>e.key==='Enter'&&add();draw()}

function structure(){const cs=prof(),nu=cs.filter(c=>c.isNum).length;let n=10;
M.innerHTML=head('🗂️','Data Structure','Upload a CSV or Excel file (or use the sample) to inspect its shape, variable names, data types and a preview. All other pages update automatically.')+
`<div class="drop" id="dz"><div class="ic">⬆️</div><h3>Drag & drop your dataset here</h3><p class="note">.csv, .tsv, .xlsx or .xls · processed locally in your browser, nothing is uploaded</p><div class="row" style="margin-top:14px"><label class="btn glow" for="fi">Choose file</label><input type="file" id="fi" hidden accept=".csv,.tsv,.txt,.xlsx,.xls"><button class="btn" id="sm">Use sample dataset</button></div></div>
<h3 class="sec">📌 ${esc(DS.name)}</h3><div class="grid4">${stat('📄',DS.rows.length,'Rows')}${stat('🧬',DS.cols.length,'Columns')}${stat('🔢',nu,'Numeric variables')}${stat('🏷️',cs.length-nu,'Categorical / text')}</div>
<div class="card"><h3>Variables & data types</h3><div class="tw"><table><tr><th>#</th><th>Variable</th><th>Type</th><th>Non-null</th><th>Missing</th><th>Unique</th><th>Examples</th></tr>${cs.map((c,i)=>`<tr><td>${i+1}</td><td><b>${esc(c.name)}</b></td><td><span class="pill">${c.type}</span></td><td>${c.n}</td><td>${c.miss}</td><td>${c.uniq}</td><td>${esc(c.sample)}</td></tr>`).join('')}</table></div></div>
<div class="card"><div class="ctl"><h3 style="flex:2;margin:0">Dataset preview</h3><label>Rows to show<select id="pr"><option>5</option><option selected>10</option><option>25</option><option>50</option><option>100</option></select></label></div><div class="tw" id="pv"></div></div>
${nu?`<div class="card"><h3>Summary statistics (numeric)</h3><div class="tw"><table><tr><th>Variable</th><th>Mean</th><th>Std</th><th>Min</th><th>25%</th><th>Median</th><th>75%</th><th>Max</th></tr>${cs.filter(c=>c.isNum).map(c=>`<tr><td><b>${esc(c.name)}</b></td>${[c.mean,c.sd,c.min,c.q1,c.med,c.q3,c.max].map(v=>`<td>${f(v)}</td>`).join('')}</tr>`).join('')}</table></div></div>`:''}`;
const pv=()=>$('#pv').innerHTML=`<table><tr><th>#</th>${DS.cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr>${DS.rows.slice(0,n).map((r,i)=>`<tr><td>${i+1}</td>${r.map(v=>`<td>${isMiss(v)?'<span class="pill High">NA</span>':esc(v)}</td>`).join('')}</tr>`).join('')}</table>`;pv();
$('#pr').onchange=e=>{n=+e.target.value;pv()};
async function ing(file){const ext=file.name.split('.').pop().toLowerCase();let rows;try{if(['csv','tsv','txt'].includes(ext))rows=csv(await file.text());else if(['xlsx','xls'].includes(ext)){await loadX();const wb=XLSX.read(await file.arrayBuffer(),{type:'array'});rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,defval:'',raw:true})}else return toast('Unsupported file – use .csv, .xlsx or .xls')}catch(e){return toast(e.message)}
rows=rows.filter(r=>r.some(c=>String(c).trim()!==''));if(rows.length<2)return toast('The file needs a header row and at least one data row');
const seen={},h=rows[0].map((c,i)=>{let s=String(c).trim()||'Column '+(i+1);seen[s]=(seen[s]||0)+1;return seen[s]>1?s+'_'+seen[s]:s});
setDS({name:file.name,cols:h,rows:rows.slice(1).map(r=>h.map((_,i)=>r[i]===undefined?'':r[i]))});toast(`Loaded ${DS.rows.length} rows × ${h.length} columns ✔`);shell();structure()}
$('#fi').onchange=e=>e.target.files[0]&&ing(e.target.files[0]);$('#sm').onclick=()=>{setDS(sample());toast('Sample dataset loaded');shell();structure()};
const dz=$('#dz');['dragover','dragenter'].forEach(v=>dz.addEventListener(v,e=>{e.preventDefault();dz.classList.add('over')}));['dragleave','drop'].forEach(v=>dz.addEventListener(v,e=>{e.preventDefault();dz.classList.remove('over')}));dz.addEventListener('drop',e=>e.dataTransfer.files[0]&&ing(e.dataTransfer.files[0]));counters()}

function patterns(){const nu=numCols(),ca=catCols(),all=prof();
M.innerHTML=head('📊','Discover Patterns','Build interactive charts to spot trends, relationships, distributions and anomalies. Hover over bars and points for exact values.')+
`<div class="card"><div class="ctl"><label>Chart type<select id="ty"><option value="hist">Histogram – distribution</option><option value="bar">Bar – category counts</option><option value="sc">Scatter – relationship</option><option value="ln">Line – trend by row order</option></select></label><label id="lx">Variable<select id="cx"></select></label><label id="ly">Y variable<select id="cy"></select></label></div><canvas id="cm"></canvas><p class="note" id="cap"></p></div>
<div class="grid2"><div class="card"><h3>🔥 Correlation heatmap</h3><div id="hm"></div><p class="note">Cyan = positive, purple = negative. Darker = stronger. Hover a cell for details.</p></div><div class="card"><h3>🔗 Strongest relationships</h3><div id="tr"></div></div></div>
<h3 class="sec">Distributions at a glance</h3><div class="grid3" id="sm"></div><div class="card"><h3>🚨 Anomaly scanner (IQR rule)</h3><div class="tw" id="an"></div></div>`;
const ty=$('#ty'),cx=$('#cx'),cy=$('#cy');
const fill=()=>{const t=ty.value,L=t==='bar'?(ca.length?ca:all):nu;cx.innerHTML=opts(L);cy.innerHTML=opts(nu,1);$('#ly').style.display=t==='sc'?'':'none';$('#lx').firstChild.textContent=t==='sc'?'X variable':'Variable';draw()};
const draw=()=>{const t=ty.value,L=t==='bar'?(ca.length?ca:all):nu,c=L[+cx.value],cap=$('#cap');if(!c){cap.textContent='No suitable column found in this dataset for this chart type.';const k=$('#cm');k.getContext('2d').clearRect(0,0,k.width,k.height);return}
if(t==='hist'){plot('#cm','bars',{...hist(c),xl:c.name});cap.innerHTML=`<b>${esc(c.name)}</b>: mean ${f(c.mean)}, median ${f(c.med)}, std ${f(c.sd)} – distribution is <b>${skewTxt(c.sk)}</b>; ${c.out} outlier${c.out==1?'':'s'} detected.`}
else if(t==='bar'){const fr=(c.freq||[]).slice(0,15);plot('#cm','bars',{l:fr.map(a=>a[0]),v:fr.map(a=>a[1]),xl:c.name});cap.innerHTML=fr.length?`<b>${esc(c.name)}</b>: ${c.uniq} unique values; most common is “${esc(fr[0][0])}” (${(fr[0][1]/c.n*100).toFixed(1)}%).`:'This column is numeric – choose a categorical column.'}
else if(t==='sc'){const d=nu[+cy.value];if(!d)return;const[X,Y]=pairs(c,d),p=pear(X,Y),[sx,sy]=sampleXY(X,Y);plot('#cm','scatter',{x:sx,y:sy,line:isFinite(p.r)?p:null,xl:`${c.name} (x) vs ${d.name} (y)`});cap.innerHTML=isFinite(p.r)?`Pearson r = <b>${p.r.toFixed(3)}</b> – a <b>${strength(p.r)} ${p.r>=0?'positive':'negative'}</b> relationship (n = ${p.n}).`:'Not enough valid pairs.'}
else{const v=c.nums,s=Math.ceil(v.length/400),sv=v.filter((_,i)=>i%s==0),sl=(sv[sv.length-1]-sv[0])/(sv.length-1||1);plot('#cm','line',{v:sv,i:sv.map((_,i)=>i*s+1),xl:'Row order → '+c.name});cap.innerHTML=`<b>${esc(c.name)}</b> across rows: overall ${sl>0?'upward':sl<0?'downward':'flat'} drift (${f(sl)} per step). Useful if rows are ordered by time.`}};
ty.onchange=fill;cx.onchange=draw;cy.onchange=draw;
if(!nu.length)ty.value='bar';fill();
const cm=corrs(),H=nu.slice(0,10),key=(a,b)=>cm.find(x=>(x.a===a&&x.b===b)||(x.a===b&&x.b===a));
$('#hm').innerHTML=H.length>1?`<div class="tw"><table class="hm"><tr><th></th>${H.map(c=>`<th>${esc(c.name.slice(0,9))}</th>`).join('')}</tr>${H.map(a=>`<tr><th>${esc(a.name.slice(0,12))}</th>${H.map(b=>{const k=a===b?{r:1}:key(a,b),r=k?k.r:NaN,al=isNaN(r)?0:Math.abs(r);return`<td title="${esc(a.name)} × ${esc(b.name)}: ${f(r)}" style="background:${r<0?`rgba(168,85,247,${al})`:`rgba(34,211,238,${al*.85})`}">${isNaN(r)?'–':r.toFixed(2)}</td>`}).join('')}</tr>`).join('')}</table></div>`:need('two or more numeric columns');
$('#tr').innerHTML=cm.length?cm.slice(0,6).map(x=>`<div class="find"><span>${x.r>0?'📈':'📉'}</span><div><b>${esc(x.a.name)} ↔ ${esc(x.b.name)}</b><br><span class="note">r = ${x.r.toFixed(3)} · ${strength(x.r)} ${x.r>0?'positive':'negative'} · p ${pf(x.p)}</span></div></div>`).join(''):'<p class="note">No numeric pairs available.</p>';
const small=[...nu.slice(0,4),...ca.filter(c=>c.uniq>1).slice(0,2)];
$('#sm').innerHTML=small.map((c,i)=>`<div class="card"><h4>${esc(c.name)}</h4><canvas class="s" id="s${i}"></canvas></div>`).join('')||'<div class="card">No columns to chart.</div>';
small.forEach((c,i)=>{if(c.isNum)plot('#s'+i,'bars',hist(c,10));else{const fr=c.freq.slice(0,8);plot('#s'+i,'bars',{l:fr.map(a=>a[0]),v:fr.map(a=>a[1])})}});
const out=nu.filter(c=>c.out);$('#an').innerHTML=nu.length?`<table><tr><th>Variable</th><th>Outliers</th><th>Normal range</th><th>Min</th><th>Max</th><th>Status</th></tr>${nu.map(c=>`<tr><td><b>${esc(c.name)}</b></td><td>${c.out}</td><td>${f(c.lo)} → ${f(c.hi)}</td><td>${f(c.min)}</td><td>${f(c.max)}</td><td><span class="pill ${c.out?(c.out/c.n>.05?'High':'Medium'):'Low'}">${c.out?'⚠ anomalies':'clean'}</span></td></tr>`).join('')}</table>`:need('numeric columns')}

function hyp(tab){tab=tab||'corr';const nu=numCols(),ca=catCols().filter(c=>c.uniq>=2&&c.uniq<=30),T=[['corr','🔗 Correlation'],['tt','⚖️ Compare two groups'],['one','🎯 One-sample mean']];
M.innerHTML=head('🧪','Hypothesis Lab','Turn assumptions into testable hypotheses. Pick a test, choose variables and read the statistics together with the visual evidence.')+`<div class="tabs">${T.map(t=>`<button class="tab ${t[0]===tab?'on':''}" data-t="${t[0]}">${t[1]}</button>`).join('')}</div><div class="card" id="pn"></div>`;
$$('.tab').forEach(b=>b.onclick=()=>hyp(b.dataset.t));const P=$('#pn');
const al=`<label>Significance level α<select id="al"><option>0.05</option><option>0.01</option><option>0.10</option></select></label>`;
const out=(t,p,a,H0,H1,ex)=>`<div class="tiles">${t.map(([l,v])=>`<div class="tile"><span>${l}</span><b>${v}</b></div>`).join('')}</div><div class="verdict ${p<a?'rej':'ok'}">${p<a?'✅ Reject H₀':'⚠️ Fail to reject H₀'} <small>(p ${p<1e-4?'< 0.0001':'= '+p.toFixed(4)} ${p<a?'<':'≥'} α = ${a})</small></div><p class="note"><b>H₀:</b> ${H0}<br><b>H₁:</b> ${H1}</p><p style="margin-top:8px;color:var(--tx)">${ex}</p>`;
if(tab==='corr'){if(nu.length<2)return P.innerHTML=need('at least two numeric columns');
P.innerHTML=`<h3>Is there a linear relationship between two variables?</h3><div class="ctl" style="margin-top:12px"><label>Variable X<select id="a">${opts(nu,0)}</select></label><label>Variable Y<select id="b">${opts(nu,1)}</select></label>${al}<button class="btn glow" id="run">▶ Run test</button></div><div id="res"></div><canvas id="hc"></canvas>`;
const run=()=>{const a=nu[+$('#a').value],b=nu[+$('#b').value],A=+$('#al').value;if(a===b)return $('#res').innerHTML=warn('Choose two different variables.');const[X,Y]=pairs(a,b),p=pear(X,Y);if(!isFinite(p.r))return $('#res').innerHTML=warn('Not enough valid data pairs.');
$('#res').innerHTML=out([['Pearson r',p.r.toFixed(4)],['R²',(p.r**2).toFixed(4)],['n',p.n],['t-statistic',f(p.t)],['p-value',pf(p.p)],['Slope',f(p.a)]],p.p,A,`there is no linear correlation between ${esc(a.name)} and ${esc(b.name)} (ρ = 0)`,`there is a linear correlation (ρ ≠ 0)`,`${p.p<A?'There is':'There is not'} statistically significant evidence of a <b>${strength(p.r)} ${p.r>=0?'positive':'negative'}</b> relationship. Each 1-unit increase in ${esc(a.name)} is associated with a ${f(p.a)} change in ${esc(b.name)}, and ${(p.r**2*100).toFixed(1)}% of the variation is explained. <i>Correlation does not imply causation.</i>`);
const[sx,sy]=sampleXY(X,Y);plot('#hc','scatter',{x:sx,y:sy,line:p,xl:`${a.name} (x) vs ${b.name} (y) with regression line`})};
$('#run').onclick=run;run()}
else if(tab==='tt'){if(!nu.length||!ca.length)return P.innerHTML=need('one numeric column and one categorical column with 2+ groups');
P.innerHTML=`<h3>Do two groups have different average values?</h3><div class="ctl" style="margin-top:12px"><label>Numeric variable<select id="a">${opts(nu,nu.length>2?nu.length-1:0)}</select></label><label>Grouping variable<select id="g">${opts(ca,0)}</select></label><label>Group A<select id="g1"></select></label><label>Group B<select id="g2"></select></label>${al}<button class="btn glow" id="run">▶ Run test</button></div><div id="res"></div><canvas id="hc"></canvas>`;
const fg=()=>{const c=ca[+$('#g').value],o=c.freq.map(x=>`<option>${esc(x[0])}</option>`).join('');$('#g1').innerHTML=o;$('#g2').innerHTML=o;$('#g2').selectedIndex=Math.min(1,c.freq.length-1)};fg();$('#g').onchange=()=>{fg();run()};
const gv=(n,g,k)=>DS.rows.filter(r=>String(r[g.j]).trim()===k&&!isMiss(r[n.j])&&!isNaN(num(r[n.j]))).map(r=>num(r[n.j])),mean=a=>sum(a)/a.length,vr=a=>sum(a.map(x=>(x-mean(a))**2))/(a.length-1);
const run=()=>{const n=nu[+$('#a').value],g=ca[+$('#g').value],k1=$('#g1').value,k2=$('#g2').value,A=+$('#al').value;if(k1===k2)return $('#res').innerHTML=warn('Choose two different groups.');
const a=gv(n,g,k1),b=gv(n,g,k2);if(a.length<2||b.length<2)return $('#res').innerHTML=warn('Each group needs at least 2 valid values.');
const m1=mean(a),m2=mean(b),v1=vr(a),v2=vr(b),se=Math.sqrt(v1/a.length+v2/b.length),t=(m1-m2)/se,df=(v1/a.length+v2/b.length)**2/((v1/a.length)**2/(a.length-1)+(v2/b.length)**2/(b.length-1)),p=pT(t,df),sp=Math.sqrt(((a.length-1)*v1+(b.length-1)*v2)/(a.length+b.length-2)),d=(m1-m2)/sp;
if(!isFinite(p))return $('#res').innerHTML=warn('Variance is zero in both groups – test not defined.');
$('#res').innerHTML=out([[`Mean ${esc(k1)}`,f(m1)],[`Mean ${esc(k2)}`,f(m2)],['Difference',f(m1-m2)],['t (Welch)',f(t)],['df',f(df)],['p-value',pf(p)],["Cohen's d",f(d)]],p,A,`mean ${esc(n.name)} is equal for ${esc(k1)} and ${esc(k2)}`,`the means differ`,`${p<A?'The groups differ significantly':'No significant difference was found'}; effect size is <b>${Math.abs(d)<.2?'negligible':Math.abs(d)<.5?'small':Math.abs(d)<.8?'medium':'large'}</b> (|d| = ${Math.abs(d).toFixed(2)}).`);
const fr=g.freq.slice(0,10);plot('#hc','bars',{l:fr.map(x=>x[0]),v:fr.map(x=>{const z=gv(n,g,x[0]);return z.length?mean(z):0}),xl:`Mean ${n.name} by ${g.name}`})};
$('#run').onclick=run;run()}
else{if(!nu.length)return P.innerHTML=need('a numeric column');
P.innerHTML=`<h3>Is the true mean equal to a value you assume?</h3><div class="ctl" style="margin-top:12px"><label>Variable<select id="a">${opts(nu,0)}</select></label><label>Hypothesised mean μ₀<input type="number" id="mu" step="any"></label>${al}<button class="btn glow" id="run">▶ Run test</button></div><div id="res"></div><canvas id="hc"></canvas>`;
const sv=()=>$('#mu').value=+nu[+$('#a').value].mean.toFixed(0);sv();$('#a').onchange=()=>{sv();run()};
const run=()=>{const c=nu[+$('#a').value],mu=+$('#mu').value,A=+$('#al').value,n=c.nums.length;if(n<3||!c.sd)return $('#res').innerHTML=warn('Not enough variation or data for this test.');const se=c.sd/Math.sqrt(n),t=(c.mean-mu)/se,df=n-1,p=pT(t,df),tc=tcrit(df);
$('#res').innerHTML=out([['Sample mean',f(c.mean)],['μ₀',f(mu)],['t-statistic',f(t)],['df',df],['p-value',pf(p)],['95% CI',`${f(c.mean-tc*se)} – ${f(c.mean+tc*se)}`]],p,A,`the mean of ${esc(c.name)} equals ${f(mu)}`,`the mean is not ${f(mu)}`,`The sample mean is ${f(c.mean)}; ${p<A?'this differs significantly from':'this is consistent with'} the assumed value of ${f(mu)}.`);plot('#hc','bars',{...hist(c),xl:c.name+' (histogram)'})};
$('#run').onclick=run;run()}}

function quality(){const q=qual(),cs=prof(),n=q.n,lab=q.score>=85?'Excellent':q.score>=70?'Good':q.score>=50?'Needs cleaning':'Poor';
M.innerHTML=head('🛡️','Data Quality','Automated checks for missing values, duplicates, type inconsistencies, outliers and formatting problems.')+
`<div class="grid2"><div class="card" style="text-align:center"><div class="ring" style="--v:${q.score}"><b>${q.score}</b></div><h3 style="margin-top:14px">${lab}</h3><p>Overall data quality score</p></div><div class="grid2" style="grid-template-columns:1fr 1fr">${[['🕳️',q.miss,'Missing cells',(q.miss/q.cells*100||0).toFixed(1)+'%'],['👯',q.dup,'Duplicate rows',(q.dup/n*100||0).toFixed(1)+'%'],['🔀',q.mixed.length,'Mixed-type columns',''],['🚨',q.outs,'Outlier values',''],['🏷️',q.ws.length+q.cse.length,'Formatting issues',''],['📏',q.cons.length,'Constant columns','']].map(x=>`<div class="card stat hov" style="padding:14px"><b data-n="${x[1]}">0</b> <i>${x[3]}</i><span>${x[0]} ${x[2]}</span></div>`).join('')}</div></div>
<div class="grid2"><div class="card"><h3>Missing values by column (%)</h3><canvas id="c1" class="s" style="height:230px"></canvas></div><div class="card"><h3>Outliers by numeric column</h3><canvas id="c2" class="s" style="height:230px"></canvas></div></div>
<div class="card"><div class="ctl"><h3 style="flex:2;margin:0">Detected problems (${q.issues.length})</h3><button class="btn glow" id="cl">🧹 Apply auto-clean</button><button class="btn" id="dc">⬇ Cleaned CSV</button></div>${q.issues.length?`<div class="tw"><table><tr><th>Severity</th><th>Column</th><th>Problem</th><th>Suggested fix</th></tr>${q.issues.map(i=>`<tr><td><span class="pill ${i[0]}">${i[0]}</span></td><td><b>${esc(i[1])}</b></td><td>${i[2]}</td><td>${i[3]}</td></tr>`).join('')}</table></div>`:'<p>🎉 No problems detected – this dataset is clean.</p>'}<p class="note">Auto-clean removes exact duplicate rows and trims whitespace. Missing values, outliers and type issues need your judgement.</p></div>`;
plot('#c1','bars',{l:cs.map(c=>c.name),v:cs.map(c=>+(c.miss/n*100).toFixed(1))});const nu=cs.filter(c=>c.isNum&&!c.id);plot('#c2','bars',{l:nu.map(c=>c.name),v:nu.map(c=>c.out)});
const clean=()=>{const seen=new Set(),rows=[];DS.rows.forEach(r=>{r=r.map(v=>typeof v==='string'?v.trim():v);const k=r.join('\u0001');if(!seen.has(k)){seen.add(k);rows.push(r)}});return rows};
$('#cl').onclick=()=>{const b=DS.rows.length,rows=clean();setDS({...DS,rows});toast(`Cleaned: ${b-rows.length} duplicate rows removed, whitespace trimmed`);shell();quality()};$('#dc').onclick=()=>save('cleaned_'+DS.name.replace(/\W+/g,'_')+'.csv',toCSV(DS.cols,clean()),'text/csv');counters()}

function findings(){const cs=prof(),q=qual(),nu=numCols(),n=DS.rows.length,F=[],Rc=[],cm=corrs();
F.push(['📦',`“${DS.name}” contains <b>${n.toLocaleString()}</b> rows and <b>${cs.length}</b> variables (${cs.filter(c=>c.isNum).length} numeric, ${cs.filter(c=>!c.isNum).length} categorical/text).`]);
if(cm[0])F.push(['🔗',`Strongest relationship: <b>${esc(cm[0].a.name)} ↔ ${esc(cm[0].b.name)}</b> (r = ${cm[0].r.toFixed(2)}, ${strength(cm[0].r)} ${cm[0].r>0?'positive':'negative'}, p ${pf(cm[0].p)}).`]);
const sk=[...nu].sort((a,b)=>Math.abs(b.sk)-Math.abs(a.sk))[0];if(sk&&Math.abs(sk.sk)>=.5)F.push(['📐',`<b>${esc(sk.name)}</b> is ${skewTxt(sk.sk)} (skew ${sk.sk.toFixed(2)}).`]);
const top=cs.filter(c=>!c.isNum&&c.freq&&c.freq[0]&&c.uniq>1).sort((a,b)=>b.freq[0][1]/b.n-a.freq[0][1]/a.n)[0];if(top)F.push(['🏷️',`<b>${esc(top.name)}</b> is dominated by “${esc(top.freq[0][0])}” (${(top.freq[0][1]/top.n*100).toFixed(0)}% of records).`]);
F.push(['🕳️',q.miss?`${q.miss} cells (${(q.miss/q.cells*100).toFixed(1)}%) are missing; worst column: <b>${esc([...cs].sort((a,b)=>b.miss-a.miss)[0].name)}</b>.`:'No missing values were found.']);
F.push(['🚨',`${q.outs} outlier values, ${q.dup} duplicate rows and ${q.mixed.length} mixed-type column(s) were detected. Quality score: <b>${q.score}/100</b>.`]);
if(q.miss)Rc.push('Impute missing numeric values with the median and categorical values with the mode – or drop columns that are mostly empty.');if(q.dup)Rc.push('Remove duplicate rows (use “Apply auto-clean” on the Data Quality page).');if(q.mixed.length)Rc.push(`Fix non-numeric entries in ${q.mixed.map(c=>esc(c.name)).join(', ')}.`);if(q.outs)Rc.push('Investigate outliers against domain knowledge before removing or capping them.');if(q.ws.length||q.cse.length)Rc.push('Standardise text labels (trim spaces, consistent capitalisation).');
if(cm[0]&&Math.abs(cm[0].r)>=.3)Rc.push(`Use ${esc(cm[0].a.name)} and ${esc(cm[0].b.name)} as starting features for modelling and test further with the Hypothesis Lab.`);if(sk&&Math.abs(sk.sk)>=1)Rc.push(`Consider a log or square-root transform for ${esc(sk.name)}.`);
Rc.push('Document every cleaning step so the analysis is reproducible, then validate findings on new data.');
const C=[`The dataset is ${q.score>=70?'suitable for further modelling':'not yet ready for modelling'} (quality ${q.score}/100).`,cm[0]?`Relationships exist between numeric variables, but correlation alone does not prove causation.`:'Too few numeric variables to measure correlations.',`${q.issues.length} data-quality issue(s) should be resolved before drawing final conclusions.`];
return{F,Rc,C}}
function report(){const{F,Rc,C}=findings(),cs=prof(),q=qual(),tag=s=>s.replace(/<[^>]+>/g,''),mine=LS.get('dq_q',[]),cm=corrs().slice(0,5);
return`<!DOCTYPE html><html><head><meta charset="utf-8"><title>EDA Report – ${esc(DS.name)}</title><style>body{font:15px/1.6 Segoe UI,Arial,sans-serif;max-width:900px;margin:30px auto;padding:0 20px;color:#1e1b3a}h1{color:#6d28d9}h2{border-bottom:2px solid #22d3ee;padding-bottom:4px;margin-top:28px;color:#4338ca}table{border-collapse:collapse;width:100%;font-size:13px}td,th{border:1px solid #ddd;padding:6px 9px;text-align:left}th{background:#ede9fe}.s{font-size:30px;font-weight:800;color:#0891b2}</style></head><body><h1>◈ DataQuest – EDA Report</h1><p>Dataset: <b>${esc(DS.name)}</b> · Generated ${new Date().toLocaleString()}</p>
<h2>1. Overview</h2><p>${DS.rows.length} rows × ${cs.length} columns. Data quality score: <span class="s">${q.score}/100</span></p>
<h2>2. Questions asked</h2><ul>${(mine.length?mine:['(none saved)']).map(x=>`<li>${esc(x)}</li>`).join('')}</ul>
<h2>3. Variables</h2><table><tr><th>Variable</th><th>Type</th><th>Missing</th><th>Unique</th><th>Mean</th><th>Median</th><th>Std</th><th>Min</th><th>Max</th></tr>${cs.map(c=>`<tr><td>${esc(c.name)}</td><td>${c.type}</td><td>${c.miss}</td><td>${c.uniq}</td>${c.isNum?[c.mean,c.med,c.sd,c.min,c.max].map(v=>`<td>${f(v)}</td>`).join(''):'<td colspan=5>–</td>'}</tr>`).join('')}</table>
<h2>4. Key correlations</h2><ul>${cm.map(x=>`<li>${esc(x.a.name)} ↔ ${esc(x.b.name)}: r = ${x.r.toFixed(3)} (${strength(x.r)}, p ${pf(x.p)})</li>`).join('')||'<li>n/a</li>'}</ul>
<h2>5. Data quality issues</h2><table><tr><th>Severity</th><th>Column</th><th>Problem</th><th>Fix</th></tr>${q.issues.map(i=>`<tr><td>${i[0]}</td><td>${esc(i[1])}</td><td>${i[2]}</td><td>${i[3]}</td></tr>`).join('')||'<tr><td colspan=4>None</td></tr>'}</table>
<h2>6. Findings</h2><ul>${F.map(x=>`<li>${tag(x[1])}</li>`).join('')}</ul><h2>7. Conclusions</h2><ul>${C.map(x=>`<li>${x}</li>`).join('')}</ul><h2>8. Recommendations</h2><ol>${Rc.map(x=>`<li>${tag(x)}</li>`).join('')}</ol><p style="color:#888;margin-top:40px">Generated by DataQuest – Explore Beyond Data</p></body></html>`}
function insights(){const{F,Rc,C}=findings(),q=qual(),vis=LS.get('dq_vis',[]);
M.innerHTML=head('💡','Final Insights','Automatically generated findings, conclusions and recommendations based on the active dataset.')+
`<div class="grid4">${stat('✅',q.score,'Quality score','/100')}${stat('🧭',vis.length,'Stages visited','/7')}${stat('❓',LS.get('dq_q',[]).length,'Your questions')}${stat('⚠️',q.issues.length,'Issues found')}</div>
<div class="grid2"><div class="card"><h3>🔎 Key findings</h3>${F.map(x=>`<div class="find"><span>${x[0]}</span><div>${x[1]}</div></div>`).join('')}</div><div class="card"><h3>🏁 Conclusions</h3>${C.map(x=>`<div class="find"><span>✔️</span><div>${x}</div></div>`).join('')}<h3 style="margin-top:18px">🛠️ Recommendations</h3>${Rc.map((x,i)=>`<div class="find"><span>${i+1}.</span><div>${x}</div></div>`).join('')}</div></div>
<div class="card" style="text-align:center"><h3>📄 Your EDA report is ready</h3><p style="margin-bottom:14px">Includes overview, questions, variable statistics, correlations, quality issues, findings and recommendations.</p><div class="row"><button class="btn glow big" id="dr">⬇ Download EDA Report</button><button class="btn big" id="pr">🖨 Print / Save as PDF</button></div>${vis.length<7?`<p class="note">Tip: you have visited ${vis.length}/7 stages – complete the rest for a fuller analysis.</p>`:'<p class="note">🎉 All 7 EDA stages completed!</p>'}</div>`;
$('#dr').onclick=()=>save('DataQuest_EDA_Report.html',report(),'text/html');$('#pr').onclick=()=>window.print();counters()}

/* ---------- boot ---------- */
const PAGES={index:home,questions,structure,patterns,hypothesis:()=>hyp(),quality,insights};
function boot(){shell();PAGES[cur]()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
