# DataQuest – Explore Beyond Data
Multi-page Exploratory Data Analysis (EDA) website – pure HTML, CSS and JavaScript (no build step).

## Run locally
Double-click `index.html`, or run `python -m http.server 8000` in this folder and open http://localhost:8000

## Deploy
- **Netlify:** drag-and-drop this folder at https://app.netlify.com/drop
- **GitHub Pages:** push the files to a repo -> Settings -> Pages -> Deploy from branch (main, root).

## Notes
- CSV works fully offline. Excel (.xlsx/.xls) loads the SheetJS reader from a CDN, so it needs internet.
- The dataset and progress are stored in your browser (localStorage). Datasets over ~4,000 rows may be truncated for storage.
- Sample dataset: use "Download sample CSV" on the Home page to test uploads.
